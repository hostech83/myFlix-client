# myFlix-client

This is a single-page application built using React, Sass, and Parcel for bundling.

## Getting Started

1. Clone the repository.
2. Run `npm install` to install dependencies.
3. Run `npm start` to start the development server.
4. Open `http://localhost:1234` to view the app.

## Build

To create a production build, run `npm run build`.
